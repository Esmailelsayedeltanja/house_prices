#!/usr/bin/env python
# coding: utf-8

# In[1]:


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression 
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


# In[2]:


housing = pd.read_csv('housing.csv')


# In[3]:


housing.shape


# In[4]:


housing.head()


# In[5]:


housing.head(10)


# In[6]:


housing.tail()


# In[7]:


housing.tail(10)


# In[8]:


housing.plot("median_income", "median_house_value")


# In[9]:


housing.plot.scatter("median_income", "median_house_value")


# In[14]:


x_train, x_test, y_train, y_test = train_test_split(housing.median_income, housing.median_house_value, test_size = 0.2)


# In[16]:


regr = LinearRegression()


# In[ ]:


preds = regr.predict(np.array(x_test).reshape(-1,1))


# In[18]:


y_test.head()


# In[ ]:


preds


# In[ ]:


residuals = preds - y_test


# In[ ]:


plt.hist(residuals)


# In[ ]:


mean_squared_error(y_test, preds) ** 0.5


# In[ ]:




